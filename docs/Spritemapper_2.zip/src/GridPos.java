public class GridPos
{
    public int x;
    public int y;

    public GridPos( int x, int y )
    {
        this.x = x;
        this.y = y;
    }
}
