public class Rectangle
{
    public int x;
    public int y;
    public int width;
    public int height;

    public Rectangle( int x, int y, int width, int height )
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public Rectangle(Rectangle source)
    {
        this.x = source.x;
        this.y = source.y;
        this.width = source.width;
        this.height = source.height;
    }

    public String readable()
    {
        return String.valueOf( x ) + ", " + String.valueOf( y ) + " w: " + String.valueOf( width ) + " / h: " + String.valueOf( height );
    }
}
