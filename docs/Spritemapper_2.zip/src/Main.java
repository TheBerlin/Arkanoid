import processing.core.PApplet;
import processing.core.PFont;
import processing.core.PImage;
import processing.event.MouseEvent;

import java.io.File;

public class Main extends PApplet
{
    private PImage imagemap = null;
    private PImage resizedImage = null;
    private PImage shiftImage = null;

    private int zoom = 1;
    private int displayOffsetX = 0;
    private int displayOffsetY = 0;

    private int gridSizeX = 16;
    private int gridSizeY = 16;
    private int gridOffsetX = 0;
    private int gridOffsetY = 0;

    private int gridLineX = 0;
    private int gridLineY = 0;
    private boolean gridlineVisible = false;

    private Rectangle shiftRectangle = null;
    private Rectangle shiftOriginRectangle = null;
    private boolean shifting = false;

    private boolean shiftPressed = false;
    private boolean ctrlPressed = false;
    private boolean altPressed = false;
    private boolean pixelRaster = false;

    private int backR = 255;
    private int backG = 255;
    private int backB = 255;

    private int shiftRectBrigthness = 200;
    private int shiftRectBrightnessDirection = -3;


    private void reset( boolean withGrid )
    {
        zoom = 1;
        doZoom();
        displayOffsetX = 0;
        displayOffsetY = 0;

        if ( withGrid )
        {
            gridSizeX = 16;
            gridSizeY = 16;
            gridOffsetX = 0;
            gridOffsetY = 0;
        }

        shiftRectangle = new Rectangle( 0, 0, gridSizeX, gridSizeY );
    }

    private void loadMap( String filename )
    {
        imagemap = loadImage( filename );
        reset( true );
    }

    public void infileSelected( File file )
    {
        loadMap( file.toString() );
        resizedImage = createImage( imagemap.width, imagemap.height, ARGB );
        resizedImage.copy( imagemap, 0, 0, imagemap.width, imagemap.height, 0, 0, imagemap.width, imagemap.height );
    }

    public void outfileSelected( File file )
    {
        String filename = file.toString();
        if ( !filename.contains( "." ) )
            filename += ".png";
        imagemap.save( filename );
    }

    private void plotRectInPixelArray( int x, int y, int c )
    {
        for ( int ix = x; ix < x + zoom; ix++ )
            for ( int iy = y; iy < y + zoom; iy++ )
                resizedImage.pixels[iy * resizedImage.width + ix] = c;
    }

    private void doZoom()
    {
        if ( imagemap != null )
        {
            imagemap.loadPixels();
            resizedImage = createImage( ( imagemap.width * zoom ), ( imagemap.height * zoom ), ARGB );
            resizedImage.loadPixels();

            for ( int x = 0; x < imagemap.width; x++ )
                for ( int y = 0; y < imagemap.height; y++ )
                    plotRectInPixelArray( x * zoom, y * zoom, imagemap.pixels[y * imagemap.width + x] );

            resizedImage.updatePixels();
        }
    }

    private int x2Canvas( int x )
    {
        return ( x + displayOffsetX ) * zoom;
    }

    private int y2Canvas( int y )
    {
        return ( y + displayOffsetY ) * zoom;
    }

    private int canvas2X( int x )
    {
        return x / zoom - displayOffsetX;
    }

    private int canvas2Y( int y )
    {
        return y / zoom - displayOffsetY;
    }

    private Rectangle gridRaster( GridPos gridPos )
    {
        return new Rectangle( x2Canvas( gridOffsetX + gridPos.x * gridSizeX ),
                y2Canvas( gridOffsetY + gridPos.y * gridSizeX ),
                gridSizeX * zoom,
                gridSizeY * zoom );
    }

    private GridPos findGridPos( int screenX, int screenY )
    {
        int countX = 0;
        int countY = 0;
        for ( int ix = x2Canvas( gridOffsetX ); ix < 1200 + gridSizeX; ix += gridSizeX * zoom )
        {
            countY = 0;
            for ( int iy = y2Canvas( gridOffsetY ); iy < 800 + gridSizeY; iy += gridSizeY * zoom )
            {
                if ( ix <= screenX && ix + gridSizeX * zoom > screenX &&
                        iy <= screenY && iy + gridSizeY * zoom > screenY )
                    return new GridPos( countX, countY );
                countY++;
                if ( iy > screenY )
                    break;
            }
            countX++;
        }
        return null;
    }

    private void clearImageLine( PImage img, int x, int y, int w )
    {
        int startoffset = y * img.width + x;
        int endoffset = startoffset + w;
        for ( int i = startoffset; i < endoffset - 1; i++ )
            img.pixels[i] = color( 255, 255, 255, 0 );
    }

    private void clearImagePart( PImage img, int x, int y, int w, int h )
    {
        img.loadPixels();
        for ( int i = y; i < y + h; i++ )
            clearImageLine( img, x, i, w );
        img.updatePixels();
    }

    private int altVal()
    {
        return altPressed ? 16 : 1;
    }

    private void startShifting()
    {
        if ( resizedImage != null )
        {
            shifting = true;
            shiftImage = createImage( shiftRectangle.width * zoom, shiftRectangle.height * zoom, ARGB );
            shiftImage.copy( resizedImage,
                    shiftRectangle.x * zoom, shiftRectangle.y * zoom,
                    shiftRectangle.width * zoom, shiftRectangle.height * zoom,
                    0, 0,
                    shiftRectangle.width * zoom, shiftRectangle.height * zoom );
            shiftOriginRectangle = new Rectangle( shiftRectangle );
            clearImagePart( resizedImage,
                    shiftRectangle.x * zoom, shiftRectangle.y * zoom,
                    shiftRectangle.width * zoom, shiftRectangle.height * zoom );
        }
    }

    private void stopShifting()
    {
        if ( shiftImage != null )
        {
            resizedImage.copy( shiftImage, 0, 0,
                    shiftImage.width, shiftImage.height,
                    shiftRectangle.x * zoom, shiftRectangle.y * zoom,
                    shiftImage.width, shiftImage.height );

            shiftImage = createImage( shiftImage.width, shiftImage.height, ARGB );
            shiftImage.copy( imagemap, shiftOriginRectangle.x, shiftOriginRectangle.y,
                    shiftOriginRectangle.width, shiftOriginRectangle.height,
                    0, 0,
                    shiftOriginRectangle.width, shiftOriginRectangle.height );

            clearImagePart( imagemap,
                    shiftOriginRectangle.x, shiftOriginRectangle.y,
                    shiftOriginRectangle.width, shiftOriginRectangle.height );

            imagemap.copy( shiftImage, 0, 0, shiftOriginRectangle.width, shiftOriginRectangle.height,
                    shiftRectangle.x, shiftRectangle.y, shiftOriginRectangle.width, shiftOriginRectangle.height );
            shiftImage = null;
            // shiftRectangle = null;
            shifting = false;
        }
    }

    public int modColor( int c, int mod )
    {
        int newC = c + mod;
        if ( newC > 255 )
            return 255;
        if ( newC < 0 )
            return 0;
        return newC;
    }

    public static void main( String[] args )
    {
        PApplet.main( Main.class );
    }

    @Override
    public void settings()
    {
        setSize( 1200, 800 );
    }

    @Override
    public void setup()
    {
        PFont textfont = createFont( "Arial", 25 );
        textFont( textfont );
        reset( true );
    }

    @Override
    public void draw()
    {
        background( backR, backG, backB );
        if ( resizedImage != null )
            image( resizedImage, displayOffsetX * zoom, displayOffsetY * zoom );

        if ( shifting )
            image( shiftImage, x2Canvas( shiftRectangle.x ), y2Canvas( shiftRectangle.y ) );

        if ( zoom > 2 && pixelRaster )
        {
            strokeWeight( 1 );
            stroke( color( 200, 200, 250 ) );

            for ( float ix = x2Canvas( gridOffsetX ); ix < x2Canvas( 1600 ); ix += zoom * 2 )
                line( ix, y2Canvas( gridOffsetY ), ix, 1200 );

            for ( float iy = y2Canvas( gridOffsetY ); iy < y2Canvas( 1200 ); iy += zoom * 2 )
                line( x2Canvas( gridOffsetX ), iy, 1600, iy );
        }

        strokeWeight( 1 );
        stroke( color( 255, 0, 0 ) );
        fill( 0, 0, 0, 0 );

        for ( float ix = x2Canvas( gridOffsetX ); ix < x2Canvas( 1600 ); ix += zoom * gridSizeX )
            line( ix, y2Canvas( gridOffsetY ), ix, 1200 );

        for ( float iy = y2Canvas( gridOffsetY ); iy < y2Canvas( 1200 ); iy += zoom * gridSizeY )
            line( x2Canvas( gridOffsetX ), iy, 1600, iy );

        if ( shiftRectangle != null )
        {
            if ( !shifting )
            {
                strokeWeight( 1 );
                stroke( color( 0, 150, 0 ) );
            }
            else
            {
                strokeWeight( 2 );
                stroke( color( 200 - shiftRectBrigthness, shiftRectBrigthness, 0 ) );
                if ( shiftRectBrigthness > 200 )
                    shiftRectBrightnessDirection = -3;
                if ( shiftRectBrigthness < 50 )
                    shiftRectBrightnessDirection = 3;
                shiftRectBrigthness += shiftRectBrightnessDirection;
            }
            rect( x2Canvas( shiftRectangle.x ), y2Canvas( shiftRectangle.y ), shiftRectangle.width * zoom, shiftRectangle.height * zoom );
        }

        strokeWeight( 1 );
        stroke( 0 );
        String s = "Grid-Offset : (" + String.valueOf( gridOffsetX ) + ", " + String.valueOf( gridOffsetY ) +
                "). Grid-Size : " + String.valueOf( gridSizeX ) + "x" + String.valueOf( gridSizeY );
        if ( shifting )
            s+= " S ";
        s += " [ " + String.valueOf( shiftRectangle.x ) + ", " + String.valueOf( shiftRectangle.y ) + " ]";

        // strokeWeight( 3 );
        // stroke( color( 0, 170, 0 ) );
        // line( x2Canvas( gridLineX ), y2Canvas( gridLineY ), x2Canvas( gridLineX + gridSizeX ), y2Canvas( gridLineY ) );

        fill( color( 255, 255, 255 ) );
        rect( 0, 750, 600, 800 );
        fill( color( 0, 0, 0 ) );
        text( s, 10, 790 );
    }

    @Override
    public void keyReleased()
    {
        if ( key == CODED )
        {
            if ( keyCode == SHIFT )
                shiftPressed = false;
            if ( keyCode == CONTROL )
                ctrlPressed = false;
            if ( keyCode == ALT )
                altPressed = false;
        }
        else
        {
            switch ( key )
            {
                case 'i':
                    selectInput( "select in-file...", "infileSelected", null, this );
                    break;
                case 'o':
                    selectOutput( "select out-file...", "outfileSelected", null, this );
                    break;
                case '+':
                    zoom = Math.min( zoom * 2, 10 );
                    doZoom();
                    break;
                case '-':
                    zoom = Math.max( zoom / 2, 1 );
                    doZoom();
                    break;
                case 'r':
                    reset( false );
                    break;
                case 'R':
                    reset( true );
                    break;
                case '1':
                    backR = modColor( backR, -30 );
                    break;
                case '2':
                    backG = modColor( backG, -30 );
                    break;
                case '3':
                    backB = modColor( backB, -30 );
                    break;
                case '4':
                    backR = modColor( backR, 30 );
                    break;
                case '5':
                    backG = modColor( backG, 30 );
                    break;
                case '6':
                    backB = modColor( backB, 30 );
                    break;
            }
        }
    }


    @Override
    public void keyPressed()
    {
        if ( key == CODED )
        {
            switch ( keyCode )
            {
                case SHIFT:
                    shiftPressed = true;
                    break;
                case CONTROL:
                    ctrlPressed = true;
                    break;
                case ALT:
                    altPressed = true;
                    break;
                case UP:
                    if ( !ctrlPressed )
                    {
                        if ( shiftPressed ) gridSizeY = Math.max( gridSizeY - altVal(), 4 );
                        else gridOffsetY -= altVal();
                    }
                    else
                    {
                        if ( shiftRectangle != null )
                        {
                            if ( shiftPressed ) shiftRectangle.height -= altVal();
                            else shiftRectangle.y -= altVal();
                        }
                    }
                    break;
                case DOWN:
                    if ( !ctrlPressed )
                    {
                        if ( shiftPressed ) gridSizeY += altVal();
                        else gridOffsetY += altVal();
                    }
                    else
                    {
                        if ( shiftRectangle != null )
                        {
                            if ( shiftPressed ) shiftRectangle.height += altVal();
                            else shiftRectangle.y += altVal();
                        }
                    }
                    break;
                case LEFT:
                    if ( !ctrlPressed )
                    {
                        if ( shiftPressed ) gridSizeX = Math.max( gridSizeX - altVal(), 4 );
                        else gridOffsetX -= altVal();
                    }
                    else
                    {
                        if ( shiftRectangle != null )
                        {
                            if ( shiftPressed ) shiftRectangle.width -= altVal();
                            else shiftRectangle.x -= altVal();
                        }
                    }
                    break;
                case RIGHT:
                    if ( !ctrlPressed )
                    {
                        if ( shiftPressed ) gridSizeX += altVal();
                        else gridOffsetX += altVal();
                    }
                    else
                    {
                        if ( shiftRectangle != null )
                        {
                            if ( shiftPressed ) shiftRectangle.width += altVal();
                            else shiftRectangle.x += altVal();
                        }
                    }
                    break;
            }
        }
        else
        {
            switch ( key )
            {
                case 'a':
                    displayOffsetX += altVal();
                    break;
                case 'd':
                    displayOffsetX -= altVal();
                    break;
                case 'w':
                    displayOffsetY += altVal();
                    break;
                case 's':
                    displayOffsetY -= altVal();
                    break;
                case 'p':
                    pixelRaster = !pixelRaster;
                    break;
                case 'm':
                    if ( shiftRectangle != null )
                    {
                        if ( shifting )
                            stopShifting();
                        else
                            startShifting();
                    }
                    break;
                case 'n':
                    doZoom();
                    shiftRectangle = null;
                    shifting = false;
                    break;
            }
        }
    }

    @Override
    public void mouseClicked()
    {
        if ( mouseButton == LEFT )
        {
            if ( !shiftPressed )
            {
                gridOffsetX = canvas2X( mouseX );
                gridOffsetY = canvas2Y( mouseY );
            }
            else
            {
                gridlineVisible = true;
                gridLineX = canvas2X( mouseX );
                gridLineY = canvas2Y( mouseY );
            }
        }
        else
        {
            // shiftRectangle = new Rectangle( canvas2X( mouseX ), canvas2Y( mouseY ), gridSizeX, gridSizeY );
        }
    }

    @Override
    public void mouseWheel( MouseEvent event )
    {
        int oldzoom = zoom;
        if ( event.getCount() > 0 )
            zoom = Math.max( 1, zoom - 1 );
        if ( event.getCount() < 0 )
            zoom = Math.min( 7, zoom + 1 );
        if ( oldzoom != zoom )
            doZoom();
    }

    @Override
    public void mousePressed()
    {
    }

    @Override
    public void mouseDragged( MouseEvent event )
    {
        if ( mouseButton == LEFT )
        {
            if ( !shiftPressed )
            {
                gridOffsetX = canvas2X( mouseX );
                gridOffsetY = canvas2Y( mouseY );
            }
            else
            {
                gridlineVisible = true;
                gridLineX = canvas2X( mouseX );
                gridLineY = canvas2Y( mouseY );
            }
        }
        else if ( mouseButton == RIGHT )
        {
            if ( shiftRectangle == null )
                shiftRectangle = new Rectangle( canvas2X( mouseX ), canvas2Y( mouseY ), gridSizeX, gridSizeY );
            shiftRectangle.x = canvas2X( mouseX );
            shiftRectangle.y = canvas2Y( mouseY );
        }
    }
}