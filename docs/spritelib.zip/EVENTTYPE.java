public enum EVENTTYPE
{
    ENTERFRAME,
    LEAVEFRAME
}
